# Machine-Learning-
Client Subscription Prediction


Analysed the customer dataset of a retail banking Institution for any outliners and inaccuracies.
The dataset contained details like age of the client, their job type, the duration of the call with the customer care specialist.
Applied various Machine Learning algorithms like Linear Regression to train the model.
Model Created with an accuracy of 87.3%.
